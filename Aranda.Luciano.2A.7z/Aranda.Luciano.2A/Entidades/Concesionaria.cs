﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Concesionaria
    {
        int capacidad;
        List<Vehiculo> vehiculos;

        #region constructores

        private Concesionaria ()
        {
            this.vehiculos = new List<Vehiculo>();
        }

        private Concesionaria(int capacidad) : this()
        {
            this.capacidad = capacidad;
        }

        #endregion

        #region metodos

        public static string Mostrar(Concesionaria c)
        {
            string sB;

            sB = "Capacidad: " + c.capacidad + "\n\n";
            foreach (Vehiculo vehiculo in c.vehiculos)
            {
                sB += vehiculo.ToString() + "\n";
            }
            return sB;
        }

        #endregion

        #region sobrecargas

        public static implicit operator Concesionaria(int capacidad)
        {
            Concesionaria cons = new Concesionaria(capacidad);
            return cons;
        }

        public static bool operator ==(Concesionaria c, Vehiculo v)
        {
            foreach ( Vehiculo ve in c.vehiculos)
            {
                if ( Object.Equals(v,ve) )
                { return true; }
                
                
            }

            return false;
        }

        public static bool operator !=(Concesionaria c, Vehiculo v)
        {
            return !(c == v);
        }

        public static Concesionaria operator +(Concesionaria c, Vehiculo v)
        {
            if ( c.vehiculos.Count < c.capacidad )
            {
                if ( c != v )
                {
                    c.vehiculos.Add(v);
                }
            }
            return c;
        }

        #endregion
    }
}
