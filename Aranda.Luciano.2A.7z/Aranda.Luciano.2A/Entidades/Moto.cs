﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Moto : Vehiculo
    {
        public ECilindrada cilindrada;

        #region constructor

        public Moto(string marca ,EPais pais, string modelo, float precio, ECilindrada cilindrada) : base(precio,modelo,new Fabricante(marca, pais))
        {
            this.cilindrada = cilindrada;
        }

        #endregion

        #region sobrecargas

        public static bool operator ==(Moto a, Moto b)
        {
            if ((Vehiculo)a == b && a.cilindrada == b.cilindrada)
            {
                return true;
            }

            return false;
        }

        public static bool operator !=(Moto a, Moto b)
        {
            return !(a == b);
        }

        public static implicit operator Single(Moto m)
        {
            return m.precio;
        }

        public override bool Equals(object obj)
        {
            if (obj is Moto && (Moto)obj == this)
            {
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            return (String)this + " Cilindrada:" + this.cilindrada + "\n";
        }

        #endregion


    }
}
