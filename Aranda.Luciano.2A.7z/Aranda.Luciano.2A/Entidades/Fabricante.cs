﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Fabricante
    {
        string marca;
        EPais pais;

        #region constructor

        public Fabricante (string marca, EPais pais)
        {
            this.marca = marca;
            this.pais = pais;
        }

        #endregion

        #region Sobrecargas

        public static bool operator ==(Fabricante a, Fabricante b)
        {
            if ( a.marca == b.marca && a.pais == b.pais )
            {
                return true;
            }

            return false;
        }

        public static bool operator !=(Fabricante a, Fabricante b)
        {
            return !(a == b);
        }

        public static implicit operator String(Fabricante f)
        {
            return "Marca: " + f.marca + " Pais: " + f.pais;
        }

        #endregion
    }
}
