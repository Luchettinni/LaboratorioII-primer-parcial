﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Auto : Vehiculo
    {
        ETipo tipo;

        #region constructor

        public Auto(string modelo, float precio, Fabricante fabri, ETipo tipo) : base(precio,modelo,fabri)
        {
            this.tipo = tipo;
        }

        #endregion

        #region sobrecargas

        public static bool operator ==(Auto a, Auto b)
        {
            if ( (Vehiculo) a == b && a.tipo == b.tipo )
            {
                return true;
            }

            return false;
        }

        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);
        }

        public static explicit operator Single(Auto a)
        {
            return a.precio;
        }

        public override bool Equals(object obj)
        {
            if (obj is Auto && (Auto) obj == this )
            {
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            return (String)this + " Tipo:" + this.tipo + "\n";
        }

        #endregion
    }
}
