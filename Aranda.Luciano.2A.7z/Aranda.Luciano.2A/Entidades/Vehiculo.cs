﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Vehiculo
    {
        protected Fabricante fabricante;
        protected static Random generadorDeVelocidades;
        protected string modelo;
        protected float precio;
        protected int velocidadMaxima;

        #region propiedades

        public int VelocidadMaxima
        {
            get
            {
                if ( this.velocidadMaxima == 0 )
                {
                    this.velocidadMaxima = generadorDeVelocidades.Next(100,280);
                }

                return this.velocidadMaxima;
            }
        }

        #endregion

        #region constructores

        static Vehiculo ()
        {
            generadorDeVelocidades = new Random();
        }

        public Vehiculo(float precio, string modelo, Fabricante fabri)
        {
            this.velocidadMaxima = this.VelocidadMaxima;
            this.precio = precio;
            this.modelo = modelo;
            this.fabricante = fabri;
        }

        public Vehiculo(string marca, EPais pais, string modelo, float precio) 
            : this (precio, modelo, new Fabricante(marca, pais) ) { }

        #endregion

        #region metodos

        private static string Mostrar(Vehiculo v)
        {
            return v.fabricante + "\n" + " Modelo: " + v.modelo + "\n" + " Precio: " + v.precio + "\n" +  " Vel. Maxima: " + v.velocidadMaxima + "\n";
        }

        #endregion

        #region sobrecargas

        public static bool operator ==(Vehiculo a, Vehiculo b)
        {
            if ( a.modelo == b.modelo && a.fabricante == b.fabricante )
            {
                return true;
            }

            return false;
        }

        public static bool operator !=(Vehiculo a, Vehiculo b)
        {
            return !(a == b);
        }

        public static explicit operator String(Vehiculo v)
        {
            return Mostrar(v);
        }

        #endregion
    }
}
