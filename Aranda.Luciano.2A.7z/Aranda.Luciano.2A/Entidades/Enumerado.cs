﻿public enum EPais
{
    Italia,
    Francia,
    Alemania
}

public enum ETipo
{
    Deportivo,
    Sedan,
    Coupe,
    Familiar
}

public enum ECilindrada
{
    cc50,
    cc125,
    cc250,
    cc500
}